/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { Component } from "react";
import { Link } from "react-router-dom";

export default class landing extends Component {
  state = {
    links: {
      ourLinks: [
        {
          id: 1,
          name: "Home",
          link: "/",
        },
        {
          id: 2,
          name: "About us",
          link: "/about",
        },
        {
          id: 3,
          name: "Services",
          link: "/service",
        },
        {
          id: 4,
          name: "Team",
          link: "/team",
        },
        {
          id: 5,
          name: "Blog",
          link: "/blog",
        },
      ],
      companyLink: [
        {
          id: 1,
          name: "About Company",
          link: "/company",
        },
        {
          id: 2,
          name: "our testimonials",
          link: "/testimonial",
        },
        {
          id: 3,
          name: "latest news",
          link: "/news",
        },
        {
          id: 4,
          name: "our mission",
          link: "/mission",
        },
        {
          id: 5,
          name: "get a free quote",
          link: "/quote",
        },
      ]
    },
  };
  render() {
    return (
      <footer className="footer-1 bg-blue-50 py-8 sm:py-12">
        <div className="container mx-auto px-4">
          <div className="sm:flex sm:flex-wrap sm:-mx-4 md:py-4">
            <div className="px-4 sm:w-1/2 md:w-1/4 xl:w-1/6 m-auto">
              <h5 className="text-xl mb-6 text-blue-500 font-semibold">
                LOGO.
              </h5>
              <p className="text-base text-gray-600 leading-7">
                Lorem, ipsum dolor sit amet consectetur adipisicing elit.
                Commodi doloremque sequi aspernatur ipsum, sint quod eius libero
                consectetur debitis eveniet quasi voluptatem at molestiae
                laborum?
              </p>

              <div className="flex flex-row mt-5 mb-6">
                <div
                  style={{
                    backgroundColor: "blue",
                    height: 20,
                    width: 20,
                    borderRadius: "50%",
                  }}
                ></div>
                <div
                  className="ml-3"
                  style={{
                    backgroundColor: "transparent",
                    height: 20,
                    width: 20,
                    borderRadius: "50%",
                    border: "1px solid #3782D7",
                  }}
                ></div>
                <div
                  className="ml-3"
                  style={{
                    backgroundColor: "transparent",
                    height: 20,
                    width: 20,
                    borderRadius: "50%",
                    border: "1px solid #3782D7",
                  }}
                ></div>
              </div>
            </div>
            <div className="px-4 sm:w-1/2 md:w-1/4 xl:w-1/6">
              <h5 className="text-xl font-bold mb-6">Our Links</h5>
              <ul className="list-none footer-links ">
                {this.state.links.ourLinks.map((item) => {
                  return (
                    <li key={item.id} className="mb-2">
                      <Link
                        href={item.link}
                        className="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800 active:text-blue-300 capitalize"
                      >
                        {item.name}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
            <div className="px-4 mt-6 sm:w-1/2 md:w-1/4 xl:w-1/6">
              <h5 className="text-xl font-bold mb-6">Our Company</h5>
              <ul className="list-none footer-links ">
                {this.state.links.companyLink.map((item) => {
                  return (
                    <li key={item.id} className="mb-2">
                      <Link
                        href={item.link}
                        className="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800 active:text-blue-300 capitalize"
                      >
                        {item.name}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
            <div className="px-4 mt-6 sm:w-1/2 md:w-1/4 xl:w-1/6">
              <h5 className="text-xl font-bold mb-6">Our Services</h5>
              <ul className="list-none footer-links ">
                <li className="mb-2">
                  <a
                    href="#"
                    className="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800 text-blue"
                  >
                    App Development
                  </a>
                </li>
                <li className="mb-2">
                  <a
                    href="#"
                    className="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800"
                  >
                    Web Development
                  </a>
                </li>
                <li className="mb-2">
                  <a
                    href="#"
                    className="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800"
                  >
                    Graphic Design
                  </a>
                </li>
                <li className="mb-2">
                  <a
                    href="#"
                    className="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800"
                  >
                    Web Solution
                  </a>
                </li>
                <li className="mb-2">
                  <a
                    href="#"
                    className="border-b border-solid border-transparent hover:border-purple-800 hover:text-purple-800"
                  >
                    App Design
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="border-t text-center">
          <p className="mt-6">
            @ Copyright 2020 <span className="text-blue-300">Brandoxide</span> .
            All rights reserved
          </p>
        </div>
      </footer>
    );
  }
}
